package com.example.isafe.register;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.isafe.R;
import com.example.isafe.data.DataManager;
import com.example.isafe.data.Result;
import com.example.isafe.ui.login.LoginActivity;

public class RegisterActivity extends AppCompatActivity {
    EditText firstname, lastname, email, password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity_register_form);

        firstname = (EditText)findViewById(R.id.firstname_txt);
        lastname = (EditText)findViewById(R.id.lastname_txt);
        email = (EditText)findViewById(R.id.email_txt);
        password = (EditText)findViewById(R.id.password_txt);
        final Button signupbutton = findViewById(R.id.signup);

        signupbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenLoginPage();
            }
        });
    }

    public void OpenLoginPage(){
        Intent intent = new Intent(this, LoginActivity.class);
        startActivity(intent);
    }

    public void DataInsertion(View view) {
        DataManager dataManager = new DataManager(this);

        String Result = dataManager.DataInsertion(firstname.getText().toString(), lastname.getText().toString(), email.getText().toString(), password.getText().toString());

        Toast.makeText(this, Result, Toast.LENGTH_LONG).show();

        firstname.setText("");
        lastname.setText("");
        email.setText("");
        password.setText("");
    }
}

package com.example.isafe.home;

import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;

import com.example.isafe.Home_Fragment;
import com.example.isafe.InviteFriends_Fragment;
import com.example.isafe.MyAccount_Fragment;
import com.example.isafe.R;
import com.example.isafe.Setting_Fragment;
import com.example.isafe.ui.login.SignInActivity;
import com.google.android.material.navigation.NavigationView;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    NavigationView navigationView;
    ActionBarDrawerToggle toggle;
    DrawerLayout drawerLayout;
    Toolbar toolbar;
    Fragment fragment;
    ImageView imageView1;
    TextView textView1;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);

        imageView1 = findViewById(R.id.track_me_view);
        textView1 = findViewById(R.id.track_me_txt);

        toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        navigationView = (NavigationView)findViewById(R.id.navmenu);
        drawerLayout = (DrawerLayout)findViewById((R.id.drawer_layout));

        toggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.open, R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, new Home_Fragment()).commit();
        navigationView.setCheckedItem(R.id.menu_home);

        navigationView.setNavigationItemSelectedListener(this);

        imageView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_track_me_view();
            }
        });

        textView1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_track_me_view();
            }
        });
    }

    public void open_track_me_view(){
        Intent intent = new Intent(this, SignInActivity.class);
        startActivity(intent);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_home:
                Intent intent = new Intent(this, Home.class);
                startActivity(intent);
                break;
            case R.id.menu_my_account:
                fragment = new MyAccount_Fragment();
                break;
            case R.id.menu_setting:
                fragment = new Setting_Fragment();
                break;
            case R.id.menu_invite_friends:
                fragment = new InviteFriends_Fragment();
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, fragment).commit();
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}

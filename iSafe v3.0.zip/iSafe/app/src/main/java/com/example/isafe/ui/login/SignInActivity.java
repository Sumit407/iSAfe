package com.example.isafe.ui.login;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import android.location.LocationManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.isafe.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import de.hdodenhof.circleimageview.CircleImageView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SignInActivity extends AppCompatActivity implements FetchAddress.OnTaskCompleted {

    public static final int DEFAULT_UPDATE_INTERVAL = 30;
    public static final int FAST_UPDATE_INTERVAL = 5;
    private static final int REQUEST_LOCATION_PERMISSION = 1;
    private static final int PERMISSIONS_FINE_LOCATIONS = 9;


    FloatingActionButton getlocationfloatbutton;
    EditText Address;
    TextView textView_location;
    Button buttongetlocation;
    CircleImageView user_pic;


    //boolean updateOn = false;  // variable to remember if we tracking location or not

    LocationRequest locationRequest;
    LocationCallback locationCallback;
    LocationManager locationManager;
    Location LastLocation;

    SupportMapFragment supportMapFragment;
    FusedLocationProviderClient fusedLocationProviderClient;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        getlocationfloatbutton = findViewById(R.id.location);
        Address = findViewById(R.id.geoaddress);
        buttongetlocation = findViewById(R.id.button_location);
        //textView_location = findViewById(R.id.tv_address);
        user_pic = findViewById(R.id.profile_pic);


        /*if (ContextCompat.checkSelfPermission(SignInActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(SignInActivity.this, new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION
            }, 100);
        }*/

        supportMapFragment = (SupportMapFragment)getSupportFragmentManager().findFragmentById(R.id.google_map);

        //user_pic.setBorderColor(getResources().getColor(R.color.colorAccent));
        //user_pic.setBorderWidth(4);
        buttongetlocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getLocation();
            }
        });

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
    }

    private void getLocation() {
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(SignInActivity.this);
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION},
                    REQUEST_LOCATION_PERMISSION);
        } else {
            //Toast.makeText(this, "getLocation: permissions granted", Toast.LENGTH_SHORT).show();
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {


                @Override
                public void onSuccess(final Location location) {
                    if(location != null) {
                        LastLocation = location;
                        new FetchAddress(SignInActivity.this, SignInActivity.this).execute(location);

                        supportMapFragment.getMapAsync(new OnMapReadyCallback() {

                            @Override
                            public void onMapReady(GoogleMap googleMap) {
                                LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
                                //create marker option
                                MarkerOptions markerOptions = new MarkerOptions().position(latLng).title("I am here..");

                                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 1));
                                googleMap.addMarker(markerOptions);
                            }
                        });
                    }
                    else{
                        Address.setText(R.string.no_location);
                    }
                }
            });
        }
        Address.setText(getString(R.string.address_text, getString(R.string.loading), System.currentTimeMillis()));
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSIONS_FINE_LOCATIONS:
                if(grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getLocation();
                }
                else {
                    Toast.makeText(this, "This App requires permission in order to work properly", Toast.LENGTH_SHORT).show();
                    finish();
                }
        }
    }

    @Override
    public void OnTaskCompleted(String result) {
        // update UI
        Address.setText(getString(R.string.address_text, result, System.currentTimeMillis()));
    }
}


class FetchAddress extends AsyncTask<Location, Void, String> {
    private final String TAG = FetchAddress.class.getSimpleName();
    @SuppressLint("StaticFieldLeak")
    private Context myContext;
    private OnTaskCompleted myListener;
    private Location[] params;


    FetchAddress(Context ConstructorContext, OnTaskCompleted listener){
        myContext = ConstructorContext;
        myListener = listener;
    }

    @Override
    protected String doInBackground(Location... params) {
        // geocoder object.
        Geocoder geocoder = new Geocoder(myContext, Locale.getDefault());

        Location location = params[0];

        // empty list of Address object
        List<Address> geoaddress = null;
        String resMsg = "";

        try{
            geoaddress = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 6);
            if(geoaddress == null || geoaddress.size() == 0) {
                if(resMsg.isEmpty()) {
                    resMsg = myContext.getString(R.string.no_address_found);
                    Log.e(TAG, resMsg);
                }
            }
            else {
                // if an address is found, read it into resMsg.
                Address address = geoaddress.get(0);
                ArrayList<String> addressParts = new ArrayList<>();
                for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                    addressParts.add(address.getAddressLine(i));
                }
                resMsg = TextUtils.join("\n", addressParts);
            }
        }
        catch (IOException ioException){
            resMsg = myContext.getString(R.string.service_not_available);
            Log.e(TAG, resMsg, ioException);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // catch invalid coordinate values
            resMsg = myContext.getString(R.string.invalid_coordinates);
            Log.e(TAG, resMsg, illegalArgumentException);
        }

        return resMsg;
    }

    interface OnTaskCompleted {
        void OnTaskCompleted(String result);
    }

    @Override
    protected void onPostExecute(String address) {
        myListener.OnTaskCompleted(address);
        super.onPostExecute(address);
    }

}
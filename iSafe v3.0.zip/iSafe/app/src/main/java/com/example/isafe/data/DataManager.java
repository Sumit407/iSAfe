package com.example.isafe.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.View;

import androidx.annotation.Nullable;

public class DataManager extends SQLiteOpenHelper {
    private static final String dbname = "iSafe.db";
    private static final String DATABASE_PATH = "/data/data/com.example.isafe/databases/";
    //private static final SQLiteDatabase.CursorFactory factory = null;

    public DataManager(@Nullable Context context) {
        super(context, dbname, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String query = "CREATE TABLE Signupdata (id INTEGER PRIMARY KEY AUTOINCREMENT, firstname text, lastname text, email text, password text)";
        sqLiteDatabase.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS iSafe.db");
        onCreate(sqLiteDatabase);
    }

    
    public String DataInsertion(String firstname, String lastname, String email, String password){
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("firstname", firstname);
        values.put("lastname", lastname);
        values.put("email", email);
        values.put("password", password);

        long Result = sqLiteDatabase.insert("Signupdata", null, values);

        if(Result == -1){
            return "Signup Error";
        } else{
            return "Signup complete";
        }
    }
}
